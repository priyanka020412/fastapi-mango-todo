from fastapi import APIRouter, HTTPException
from app.models import Todo
from app.database import collection
from bson import ObjectId

router = APIRouter()

# Create
@router.post("/todos")
def create_todo(todo: Todo):
    result = collection.insert_one(todo.dict())
    return {"id": str(result.inserted_id), "message": "Todo created"}

# Read All
@router.get("/todos")
def get_all_todos():
    todos = []
    for todo in collection.find():
        todo["_id"] = str(todo["_id"])
        todos.append(todo)
    return todos

# Read One
@router.get("/todos/{todo_id}")
def get_todo(todo_id: str):
    todo = collection.find_one({"_id": ObjectId(todo_id)})
    if todo:
        todo["_id"] = str(todo["_id"])
        return todo
    raise HTTPException(status_code=404, detail="Todo not found")

# Update
@router.put("/todos/{todo_id}")
def update_todo(todo_id: str, todo: Todo):
    result = collection.update_one({"_id": ObjectId(todo_id)}, {"$set": todo.dict()})
    if result.modified_count == 1:
        return {"message": "Todo updated"}
    raise HTTPException(status_code=404, detail="Todo not found")

# Delete
@router.delete("/todos/{todo_id}")
def delete_todo(todo_id: str):
    result = collection.delete_one({"_id": ObjectId(todo_id)})
    if result.deleted_count == 1:
        return {"message": "Todo deleted"}
    raise HTTPException(status_code=404, detail="Todo not found")

@router.get("/")
def home():
    return {"message": "API is working!"}
